﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Customer_CustomorAddEdit : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillDropDownList();
            if (Request.QueryString["CustomorID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["CustomorID"]));
            }
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 CustomorID)
    {
        CustomorENT entCustomor = new CustomorENT();
        CustomorBAL balCustomor = new CustomorBAL();

        entCustomor = balCustomor.SelectByPK(CustomorID);

        if (!entCustomor.CustomorName.IsNull)
            txtCustomorName.Text = entCustomor.CustomorName.Value.ToString();

        if (!entCustomor.MobileNO.IsNull)
            txtContactNO.Text = entCustomor.MobileNO.Value.ToString();

        if (!entCustomor.EmailID.IsNull)
            txtEmail.Text = entCustomor.EmailID.Value.ToString();

        if (!entCustomor.Address.IsNull)
            txtAddress.Text = entCustomor.Address.Value.ToString();

        if (!entCustomor.DriverID.IsNull)
            ddlDriverName.SelectedValue = entCustomor.DriverID.Value.ToString();

        if (!entCustomor.VillageName.IsNull)
            TxtVillage.Text = entCustomor.VillageName.Value.ToString();


        if (!entCustomor.ShopName.IsNull)
            txtShopName.Text = entCustomor.ShopName.Value.ToString();

       

        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

    #region Button :Add
    protected void btnSave_Click(object sender, EventArgs e)
    {
        #region Server Side Validation

        String strError = String.Empty;

        if (txtCustomorName.Text.Trim() == String.Empty)
            strError += "- Enter Customor Name<br />";

        if (txtContactNO.Text.Trim() == String.Empty)
            strError += "- Enter Mobile NO<br />";

        if (txtEmail.Text.Trim() == String.Empty)
            strError += "- Enter Email ID<br />";

        if (txtAddress.Text.Trim() == String.Empty)
            strError += "- Enter Current Address<br />";

        if (ddlDriverName.SelectedIndex.Equals(0))
            strError += " - Enter Driver Name<br />";

        if (TxtVillage.Text.Trim() == String.Empty)
            strError += "- Enter Village Name<br />";


        if (txtShopName.Text.Trim() == String.Empty)
            strError += "- Enter Shop Name<br />";

        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        CustomorENT entCustomor = new CustomorENT();
        CustomorBAL balCustomor = new CustomorBAL();

        #region Gather Data

        if (txtCustomorName.Text.Trim() != String.Empty)
            entCustomor.CustomorName = txtCustomorName.Text.Trim();

        if (txtContactNO.Text.Trim() != String.Empty)
            entCustomor.MobileNO = txtContactNO.Text.Trim();

        if (txtEmail.Text.Trim() != String.Empty)
            entCustomor.EmailID = txtEmail.Text.Trim();

        if (txtAddress.Text.Trim() != String.Empty)
            entCustomor.Address = txtAddress.Text.Trim();

        if (ddlDriverName.SelectedIndex > 0)
            entCustomor.DriverID = Convert.ToInt32(ddlDriverName.SelectedValue);

        if (TxtVillage.Text.Trim() != String.Empty)
            entCustomor.VillageName = TxtVillage.Text.Trim();

        if (txtShopName.Text.Trim() != String.Empty)
            entCustomor.ShopName = txtShopName.Text.Trim();

        //entCity.UserID = 28;
        if (Request.QueryString["CustomorID"] == null)
        {
            entCustomor.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["CustomorID"] == null)
        {
            balCustomor.Insert(entCustomor);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entCustomor.CustomorID = Convert.ToInt32(Request.QueryString["CustomorID"]);
            balCustomor.Update(entCustomor);
            Response.Redirect("~/Admin Panel/Customor/CustomorList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Button :Add


    #region FillDropDownList
    private void FillDropDownList()
    {
        CommonFillMethod.FillDropDownListDriverID(ddlDriverName);
    }
    #endregion FillDropDownList
    #region ClearControls

    private void ClearControls()
    {
        txtCustomorName.Text = "";
        txtContactNO.Text = "";
        txtEmail.Text = "";
        txtAddress.Text = "";
        TxtVillage.Text = "";
        txtShopName.Text = "";
        txtCustomorName.Focus();
    }

    #endregion ClearControls
   
}