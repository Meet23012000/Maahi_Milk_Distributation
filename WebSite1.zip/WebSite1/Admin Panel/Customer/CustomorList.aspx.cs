﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Customer_CustomorList : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillCustomorGridView();
            FillDropDownListVillage();
            FillDropDownList();
            FillDropDownListShop();
            
        }
    }
    #endregion Load Event

    #region Fill Customor Grid view
    private void FillCustomorGridView()
    {
        CustomorBAL balCustomor = new CustomorBAL();
        DataTable dtCustomor = balCustomor.SelectAll();
        if (dtCustomor != null && dtCustomor.Rows.Count > 0)
        {
            gvCustomor.DataSource = dtCustomor;
            gvCustomor.DataBind();
            // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
        }
        else
        {
            lblMessage.Text = "No Data Available";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    #endregion Fill Customor Grid view

    #region gvCustomor_RowCommand

    protected void gvCustomor_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            CustomorBAL balCustomor = new CustomorBAL();
            if (balCustomor.Delete(Convert.ToInt32(e.CommandArgument)))
            {
                FillCustomorGridView();
            }
            else
            {
                lblMessage.Text = balCustomor.Message;
            }
        }
    }

    #endregion gvCustomor_RowCommand

    #region FillDropDownList
    private void FillDropDownList()
    {
        CommonFillMethod.FillDropDownListVehicleID(ddlDriverName);
    }
    #endregion FillDropDownList

    #region FillDropDownListVillage
    private void FillDropDownListVillage()
    {
        CommonFillMethod.FillDropDownListVillageCustomorID(dllVillage);
    }
    #endregion FillDropDownListVillage

    #region FillDropDownListShop
    private void FillDropDownListShop()
    {
        CommonFillMethod.FillDropDownListShopCustomorID(dllShopName);
    }
    #endregion FillDropDownListShop

    #region search filter
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        #region Local Variables

        SqlString strDriverID = SqlString.Null;
        SqlString strVillageName = SqlString.Null;
        SqlString strShopName = SqlString.Null;

        #endregion Local Variables

        #region Read Data
        if (ddlDriverName.SelectedIndex > 0)
        {
            strDriverID = ddlDriverName.SelectedValue;
        }
        if (dllVillage.SelectedIndex > 0)
        {
            strVillageName = dllVillage.SelectedValue;
        }
        if (dllShopName.SelectedIndex > 0)
        {
            strShopName = dllShopName.SelectedValue;
        }

        #endregion Read Data

        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.Parameters.AddWithValue("@DriverID", ddlDriverName.SelectedValue);
                    objcmd.Parameters.AddWithValue("@VillageName", dllVillage.SelectedValue);
                    objcmd.Parameters.AddWithValue("@ShopName", dllShopName.SelectedValue);
                   
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Customor_SelectAllSearchFilter";


                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();



                    #region Data Table

                    CustomorBAL balCustomor = new CustomorBAL();
                    DataTable dtCustomor = balCustomor.SelectAll();
                    if (dtCustomor != null && dtCustomor.Rows.Count > 0)
                    {
                        gvCustomor.DataSource = dtCustomor;
                        gvCustomor.DataBind();
                        // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
                    }
                    else
                    {
                        lblMessage.Text = "No Data Available";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                    #endregion Data Table



                   


                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {





                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }
    }
    #endregion search filter


}