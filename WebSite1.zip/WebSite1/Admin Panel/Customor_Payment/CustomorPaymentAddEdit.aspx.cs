﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Customor_Payment_CustomorPaymentAddEdit : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["CustomorPaymentID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["CustomorPaymentID"]));
            }
            FillDropDownList();
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 CustomorPaymentID)
    {
        CustomorPaymentENT entCustomorPayment = new CustomorPaymentENT();
        CustomorPaymentBAL balCustomorPayment = new CustomorPaymentBAL();

        entCustomorPayment = balCustomorPayment.SelectByPK(CustomorPaymentID);

        

        if (!entCustomorPayment.CustomorID.IsNull)
            ddlCustomorName.SelectedValue = entCustomorPayment.CustomorID.Value.ToString();

        if (!entCustomorPayment.TotalAmount.IsNull)
            txtTotalAmount.Text = entCustomorPayment.TotalAmount.Value.ToString();

        if (!entCustomorPayment.PaidAmount.IsNull)
            txtPaidAmount.Text = entCustomorPayment.PaidAmount.Value.ToString();


        if (!entCustomorPayment.PaymentDate.IsNull)
            txtDate.Text = entCustomorPayment.PaymentDate.Value.ToString();


       


        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

    #region Save Button
    protected void btnSave_Click1(object sender, EventArgs e)
    {
    
        #region Server Side Validation

        String strError = String.Empty;

        if (txtTotalAmount.Text.Trim() == String.Empty)
            strError += "- Enter Total Amount<br />";

        if (txtPaidAmount.Text.Trim() == String.Empty)
            strError += "- Enter Paid Amount<br />";

        if (ddlCustomorName.SelectedIndex.Equals(0))
          strError += "- Select Customor Name <br />";



        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        CustomorPaymentENT entCustomorPayment = new CustomorPaymentENT();
        CustomorPaymentBAL balCustomorPayment = new CustomorPaymentBAL();
        #region Gather Data

       

        if (ddlCustomorName.SelectedIndex > 0)
            entCustomorPayment.CustomorID = Convert.ToInt32(ddlCustomorName.SelectedValue);

        if (txtTotalAmount.Text.Trim() != String.Empty)
            entCustomorPayment.TotalAmount = txtTotalAmount.Text.Trim();

        if (txtPaidAmount.Text.Trim() != String.Empty)
            entCustomorPayment.PaidAmount = txtPaidAmount.Text.Trim();

        if (txtDate.Text.Trim() != String.Empty)
            entCustomorPayment.PaymentDate = Convert.ToDateTime(txtDate.Text.Trim());

        



        //entCity.UserID = 28;
        if (Request.QueryString["CustomorPaymentID"] == null)
        {
            entCustomorPayment.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["CustomorPaymentID"] == null)
        {
            balCustomorPayment.Insert(entCustomorPayment);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entCustomorPayment.CustomorPaymentID = Convert.ToInt32(Request.QueryString["CustomorPaymentID"]);
            balCustomorPayment.Update(entCustomorPayment);
            Response.Redirect("~/Admin Panel/CustomorPayment/CustomorPaymentList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Save Button

    #region FillDropDownList
    private void FillDropDownList()
    {
        CommonFillMethod.FillDropDownListCustomorID(ddlCustomorName);
    }
    #endregion FillDropDownList

    #region ClearControls

    private void ClearControls()
    {
        
        ddlCustomorName.SelectedIndex = 0;
        txtTotalAmount.Text = "";
        txtPaidAmount.Text = "";
        txtDate.Text = "";
    }

    #endregion ClearControls
   
}