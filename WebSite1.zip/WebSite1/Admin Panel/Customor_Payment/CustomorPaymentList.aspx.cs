﻿using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Customor_Payment_CustomorPaymentList : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillCustomorPaymentGridView();
        }
    }
    #endregion Load Event

    #region Fill CustomorPayment Grid view
    private void FillCustomorPaymentGridView()
    {
        CustomorPaymentBAL balCustomorPayment = new CustomorPaymentBAL();
        DataTable dtCustomorPayment = balCustomorPayment.SelectAll();
        if (dtCustomorPayment != null && dtCustomorPayment.Rows.Count > 0)
        {
            gvCustomorPayment.DataSource = dtCustomorPayment;
            gvCustomorPayment.DataBind();
            // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
        }
        else
        {
            lblMessage.Text = "No Data Available";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    #endregion Fill CustomorPayment Grid view

    #region gvCustomorPayment_RowCommand

    protected void gvCustomorPayment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            CustomorPaymentBAL balCustomorPayment = new CustomorPaymentBAL();
            if (balCustomorPayment.Delete(Convert.ToInt32(e.CommandArgument)))
            {
                FillCustomorPaymentGridView();
            }
            else
            {
                lblMessage.Text = balCustomorPayment.Message;
            }
        }
    }

    #endregion gvDriver_RowCommand
}