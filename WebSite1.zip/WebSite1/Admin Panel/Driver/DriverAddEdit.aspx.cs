﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Driver_DriverAddEdit : System.Web.UI.Page
{
   

     #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["DriverID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["DriverID"]));
            }
            FillDropDownList();
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 DriverID)
    {
        DriverENT entDriver = new DriverENT();
        DriverBAL balDriver = new DriverBAL();

        entDriver = balDriver.SelectByPK(DriverID);

        if (!entDriver.DriverName.IsNull)
            txtDriverName.Text = entDriver.DriverName.Value.ToString();

        if (!entDriver.MobileNO.IsNull)
            txtMobileNO.Text = entDriver.MobileNO.Value.ToString();

        if (!entDriver.Address.IsNull)
            txtAddress.Text = entDriver.Address.Value.ToString();

        if (!entDriver.VehicleID.IsNull)
            ddlVehicleNO.SelectedValue = entDriver.VehicleID.Value.ToString();

        if (!entDriver.LicenseNO.IsNull)
            txtLicenseNO.Text = entDriver.LicenseNO.Value.ToString();

        if (!entDriver.LicenseExpiredDate.IsNull)
            txtExpiredDate.Text = entDriver.LicenseExpiredDate.Value.ToString();


        if (!entDriver.LicensePath.IsNull)
            imgDriver.ImageUrl = entDriver.LicensePath.Value.ToString();

        

        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

     #region Save Button
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strFilePath = "~/Images/AdharCard";
         #region Server Side Validation

        String strError = String.Empty;

        if (txtDriverName.Text.Trim() == String.Empty)
            strError += "- Enter Driver Name<br />";

        if (txtMobileNO.Text.Trim() == String.Empty)
            strError += "- Enter Mobile NO<br />";

        if (txtAddress.Text.Trim() == String.Empty)
            strError += "- Enter Current Address <br />";

        //if (ddlVehicleNO.SelectedIndex.Equals(0))
          //  strError += "- Select Current Vehicle NO <br />";

        if (ddlVehicleNO.SelectedIndex.Equals(0))
            strError += " - Enter Vehicle No<br />";



        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        DriverENT entDriver = new DriverENT();
        DriverBAL balDriver = new DriverBAL();

        #region Gather Data

        if (txtDriverName.Text.Trim() != String.Empty)
            entDriver.DriverName = txtDriverName.Text.Trim();

        if (txtMobileNO.Text.Trim() != String.Empty)
            entDriver.MobileNO = txtMobileNO.Text.Trim();

         if (txtAddress.Text.Trim() != String.Empty)
            entDriver.Address = txtAddress.Text.Trim();

          if (ddlVehicleNO.SelectedIndex > 0)
            entDriver.VehicleID = Convert.ToInt32(ddlVehicleNO.SelectedValue);

         if (txtLicenseNO.Text.Trim() != String.Empty)
            entDriver.LicenseNO = txtLicenseNO.Text.Trim();
        
         if (txtExpiredDate.Text.Trim() != String.Empty)
            entDriver.LicenseExpiredDate = Convert.ToDateTime(txtExpiredDate.Text.Trim());

         if (fuimg.HasFile)
            {
                imgDriver.ImageUrl = strFilePath + fuimg.FileName;
                entDriver.LicensePath = imgDriver.ImageUrl;
                fuimg.SaveAs(Server.MapPath(strFilePath + fuimg.FileName));
                //lblMessage.Text = Server.MapPath(strProofPhoto + fuProofPhoto.FileName);
            }
            else
            {
                entDriver.LicensePath = imgDriver.ImageUrl;
            }

        

        //entCity.UserID = 28;
        if (Request.QueryString["DriverID"] == null)
        {
            entDriver.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["DriverID"] == null)
        {
            balDriver.Insert(entDriver);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entDriver.DriverID = Convert.ToInt32(Request.QueryString["DriverID"]);
            balDriver.Update(entDriver);
            Response.Redirect("~/Admin Panel/Driver/DriverList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Save Button

    #region FillDropDownList
    private void FillDropDownList()
    {
        CommonFillMethod.FillDropDownListVehicleID(ddlVehicleNO);
    }
    #endregion FillDropDownList

    #region ClearControls

    private void ClearControls()
    {
        txtDriverName.Text = "";
        txtMobileNO.Text = "";
        txtAddress.Text = "";
        ddlVehicleNO.SelectedIndex = 0;
        txtLicenseNO.Text = "";
        txtExpiredDate.Text = "";
        txtDriverName.Focus();
    }

    #endregion ClearControls
}