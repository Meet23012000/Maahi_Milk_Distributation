﻿using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Driver_DriverList : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillDriverGridView();
        }
    }
    #endregion Load Event

    #region Fill Driver Grid view
    private void FillDriverGridView()
    {
        DriverBAL balDriver = new DriverBAL();
        DataTable dtDriver = balDriver.SelectAll();
        if (dtDriver != null && dtDriver.Rows.Count > 0)
        {
            gvDriver.DataSource = dtDriver;
            gvDriver.DataBind();
            // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
        }
        else
        {
            lblMessage.Text = "No Data Available";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    #endregion Fill Product Grid view

    #region gvDriver_RowCommand

    protected void gvDriver_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            DriverBAL balDriver = new DriverBAL();
            if (balDriver.Delete(Convert.ToInt32(e.CommandArgument)))
            {
                FillDriverGridView();
            }
            else
            {
                lblMessage.Text = balDriver.Message;
            }
        }
    }

    #endregion gvDriver_RowCommand
}