﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Product_ProductAddEdit : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["ProductID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["ProductID"]));
            }
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 ProductID)
    {
        ProductENT entProduct = new ProductENT();
        ProductBAL balProduct = new ProductBAL();

        entProduct = balProduct.SelectByPK(ProductID);

        if (!entProduct.ProductName.IsNull)
            txtProductName.Text = entProduct.ProductName.Value.ToString();

        if (!entProduct.ProductRate.IsNull)
            txtRate.Text = entProduct.ProductRate.Value.ToString();

        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

    #region Button :Add
    protected void btnSave_Click(object sender, EventArgs e)
    {
        #region Server Side Validation

        String strError = String.Empty;

        if (txtProductName.Text.Trim() == String.Empty)
            strError += "- Enter Product Name<br />";

        if (txtRate.Text.Trim() == String.Empty)
            strError += "- Enter Product Rate<br />";

        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        ProductENT entProduct = new ProductENT();
        ProductBAL balProduct = new ProductBAL();

        #region Gather Data

        if (txtProductName.Text.Trim() != String.Empty)
            entProduct.ProductName = txtProductName.Text.Trim();

        if (txtRate.Text.Trim() != String.Empty)
            entProduct.ProductRate = txtRate.Text.Trim();

        //entCity.UserID = 28;
        if (Request.QueryString["ProductID"] == null)
        {
            entProduct.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["ProductID"] == null)
        {
            balProduct.Insert(entProduct);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entProduct.ProductID = Convert.ToInt32(Request.QueryString["ProductID"]);
            balProduct.Update(entProduct);
            Response.Redirect("~/Admin Panel/Product/ProductList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Button :Add

    #region ClearControls

    private void ClearControls()
    {
        txtProductName.Text = "";
        txtRate.Text = "";
        txtProductName.Focus();
    }

    #endregion ClearControls
}