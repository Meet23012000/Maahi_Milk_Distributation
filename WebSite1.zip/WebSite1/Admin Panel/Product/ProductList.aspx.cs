﻿using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Product_ProductList : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillProductGridView();
        }
    }
    #endregion Load Event

    #region Fill Product Grid view
    private void FillProductGridView()
    {
        ProductBAL balProduct = new ProductBAL();
        DataTable dtProduct = balProduct.SelectAll();
        if (dtProduct != null && dtProduct.Rows.Count > 0)
        {
            gvProduct.DataSource = dtProduct;
            gvProduct.DataBind();
           // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
        }
        else
        {
            lblMessage.Text = "No Data Available";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    #endregion Fill Product Grid view

    #region gvProduct_RowCommand

    protected void gvProduct_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            ProductBAL balProduct = new ProductBAL();
            if (balProduct.Delete(Convert.ToInt32(e.CommandArgument)))
            {
                FillProductGridView();
            }
            else
            {
                lblMessage.Text = balProduct.Message;
            }
        }
    }

    #endregion gvCountry_RowCommand

}