﻿using MahiMilkDistribution;
using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Route_RouteAddEdit : System.Web.UI.Page
{

    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["RouteID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["RouteID"]));
            }
            FillDropDownList();
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 RouteID)
    {
        RouteENT entRoute = new RouteENT();
        RouteBAL balRoute = new RouteBAL();

        entRoute = balRoute.SelectByPK(RouteID);

        if (!entRoute.RouteNO.IsNull)
            txTRouteNO.Text = entRoute.RouteNO.Value.ToString();

        if (!entRoute.RouteName.IsNull)
            txtRouteName.Text = entRoute.RouteName.Value.ToString();



        if (!entRoute.DriverID.IsNull)
            ddlDriverName.SelectedValue = entRoute.DriverID.Value.ToString();

       



        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

    #region Save Button
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        
        #region Server Side Validation

        String strError = String.Empty;

        if (txTRouteNO.Text.Trim() == String.Empty)
            strError += "- Enter Route NO<br />";

        if (txtRouteName.Text.Trim() == String.Empty)
            strError += "- Enter Route Name<br />";


        if (ddlDriverName.SelectedIndex.Equals(0))
          strError += "- Select Current Driver Name <br />";



        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        RouteENT entRoute = new RouteENT();
        RouteBAL balRoute = new RouteBAL();
        #region Gather Data

        if (txTRouteNO.Text.Trim() != String.Empty)
            entRoute.RouteNO = txTRouteNO.Text.Trim();

        if (txtRouteName.Text.Trim() != String.Empty)
            entRoute.RouteName = txtRouteName.Text.Trim();



        if (ddlDriverName.SelectedIndex > 0)
            entRoute.DriverID = Convert.ToInt32(ddlDriverName.SelectedValue);

       

        //entCity.UserID = 28;
        if (Request.QueryString["RouteID"] == null)
        {
            entRoute.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["RouteID"] == null)
        {
            balRoute.Insert(entRoute);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entRoute.RouteID = Convert.ToInt32(Request.QueryString["RouteID"]);
            balRoute.Update(entRoute);
            Response.Redirect("~/Admin Panel/Route/RouteList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Save Button

    #region FillDropDownList
    private void FillDropDownList()
    {
        CommonFillMethod.FillDropDownListDriverID(ddlDriverName);
    }
    #endregion FillDropDownList

    #region ClearControls

    private void ClearControls()
    {
        txTRouteNO.Text = "";
        txtRouteName.Text = "";

        ddlDriverName.SelectedIndex = 0;
        
        txTRouteNO.Focus();
    }

    #endregion ClearControls
   
}