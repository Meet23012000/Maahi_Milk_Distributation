﻿using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Route_RouteList : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillRouteGridView();
        }
    }
    #endregion Load Event

    #region Fill Route Grid view
    private void FillRouteGridView()
    {
        RouteBAL balRoute = new RouteBAL();
        DataTable dtRoute = balRoute.SelectAll();
        if (dtRoute != null && dtRoute.Rows.Count > 0)
        {
            gvRoute.DataSource = dtRoute;
            gvRoute.DataBind();
            // lblMessage.Text = "No Of Records found:" + dtProduct.Rows.Count.ToString();
        }
        else
        {
            lblMessage.Text = "No Data Available";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    #endregion Fill Product Grid view

    #region gvRoute_RowCommand

    protected void gvRoute_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            RouteBAL balRoute = new RouteBAL();
            if (balRoute.Delete(Convert.ToInt32(e.CommandArgument)))
            {
                FillRouteGridView();
            }
            else
            {
                lblMessage.Text = balRoute.Message;
            }
        }
    }

    #endregion gvVehicle_RowCommand
}