﻿using MahiMilkDistribution.BAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Panel_Vehicle_VehicleAddEdit : System.Web.UI.Page
{
    #region Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["VehicleID"] != null)
            {
                LoadControls(Convert.ToInt32(Request.QueryString["VehicleID"]));
            }
        }
    }
    #endregion Load Event

    #region LoadControls
    private void LoadControls(SqlInt32 VehicleID)
    {
        VehicleENT entVehicle = new VehicleENT();
        VehicleBAL balVehicle = new VehicleBAL();

        entVehicle = balVehicle.SelectByPK(VehicleID);

        if (!entVehicle.VehicleType.IsNull)
            txtVehicleType.Text = entVehicle.VehicleType.Value.ToString();

        if (!entVehicle.VehicleNO.IsNull)
            txtVehicleNumber.Text = entVehicle.VehicleNO.Value.ToString();

        if (!entVehicle.OwnerName.IsNull)
            txtOwnerName.Text = entVehicle.OwnerName.Value.ToString();

        if (!entVehicle.MobileNO.IsNull)
            txtphoneno.Text = entVehicle.MobileNO.Value.ToString();

        //entCity.UserID = 28;
        //entState.Created = DateTime.Now;
        //entState.Modified = DateTime.Now;

    }

    #endregion LoadControls

    #region Button :Add
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        #region Server Side Validation

        String strError = String.Empty;

        if (txtVehicleType.Text.Trim() == String.Empty)
            strError += "- Enter Vehicle Type<br />";

        if (txtVehicleNumber.Text.Trim() == String.Empty)
            strError += "- Enter Vehicle NO<br />";

        if (txtOwnerName.Text.Trim() == String.Empty)
            strError += "- Enter Owner Name<br />";

        if (txtphoneno.Text.Trim() == String.Empty)
            strError += "- Enter Mobile NO<br />";

        if (strError.Trim() != String.Empty)
        {
            lblMessage.Text = "Kindly Correct Following Error(s)<br />" + strError; ;
        }

        #endregion Server Side Validation

        VehicleENT entVehicle = new VehicleENT();
        VehicleBAL balVehicle = new VehicleBAL();

        #region Gather Data

        if (txtVehicleType.Text.Trim() != String.Empty)
            entVehicle.VehicleType = txtVehicleType.Text.Trim();

        if (txtVehicleNumber.Text.Trim() != String.Empty)
            entVehicle.VehicleNO = txtVehicleNumber.Text.Trim();

        if (txtOwnerName.Text.Trim() != String.Empty)
            entVehicle.OwnerName = txtOwnerName.Text.Trim();

        if (txtphoneno.Text.Trim() != String.Empty)
            entVehicle.MobileNO = txtphoneno.Text.Trim();

        //entCity.UserID = 28;
        if (Request.QueryString["VehicleID"] == null)
        {
            entVehicle.CreationDate = DateTime.Now;
        }


        if (Request.QueryString["VehicleID"] == null)
        {
            balVehicle.Insert(entVehicle);
            lblMessage.Text = "Data Inserted Successfully";
            ClearControls();
        }
        else
        {
            entVehicle.VehicleID = Convert.ToInt32(Request.QueryString["VehicleID"]);
            balVehicle.Update(entVehicle);
            Response.Redirect("~/Admin Panel/Vehicle/VehicleList.aspx");
        }

        #endregion Gather Data
    }
    #endregion Button :Add

    #region ClearControls

    private void ClearControls()
    {
        txtVehicleType.Text = "";
        txtVehicleNumber.Text = "";
        txtOwnerName.Text = "";
        txtphoneno.Text = "";
        txtVehicleType.Focus();
    }

    #endregion ClearControls
    
}