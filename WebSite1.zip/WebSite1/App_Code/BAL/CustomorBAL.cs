﻿using MahiMilkDistribution.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorBAL
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class CustomorBAL : CustomorBALBase
    {
        public CustomorBAL()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}