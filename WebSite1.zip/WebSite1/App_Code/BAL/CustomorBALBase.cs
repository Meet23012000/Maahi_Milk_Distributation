﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorBALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class CustomorBALBase
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(CustomorENT entCustomor)
        {
            CustomorDAL customorDAL = new CustomorDAL();
            if (customorDAL.Insert(entCustomor))
            {
                return true;
            }
            else
            {
                this.Message = customorDAL.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(CustomorENT entCustomor)
        {
            CustomorDAL customorDAL = new CustomorDAL();
            if (customorDAL.Update(entCustomor))
            {
                return true;
            }
            else
            {
                this.Message = customorDAL.Message;
                return false;
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 CustomorID)
        {
            CustomorDAL customorDAL = new CustomorDAL();
            if (customorDAL.Delete(CustomorID))
            {
                return true;
            }
            else
            {
                this.Message = customorDAL.Message;
                return false;
            }
        }

        #endregion Delete Operation

        #region Select Operations

        public DataTable SelectAll()
        {
            CustomorDAL customorDAL = new CustomorDAL();
            return customorDAL.SelectAll();
        }

        public CustomorENT SelectByPK(SqlInt32 CustomorID)
        {
            CustomorDAL customorDAL = new CustomorDAL();
            return customorDAL.SelectByPK(CustomorID);
        }

        public DataTable SelectDropDownList()
        {
            CustomorDAL customorDAL = new CustomorDAL();
            return customorDAL.SelectDropDownList();
        }

        public DataTable SelectDropDownListVillage()
        {
            CustomorDAL villageDAL = new CustomorDAL();
            return villageDAL.SelectDropDownListVillage();
        }
        public DataTable SelectDropDownListShop()
        {
            CustomorDAL shopDAL = new CustomorDAL();
            return shopDAL.SelectDropDownListShop();
        }



        #endregion Select Operations
    }
}