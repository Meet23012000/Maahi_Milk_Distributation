﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorPaymentBALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class CustomorPaymentBALBase
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(CustomorPaymentENT entCustomorPayment)
        {
            CustomorPaymentDAL customorpaymentDAL = new CustomorPaymentDAL();
            if (customorpaymentDAL.Insert(entCustomorPayment))
            {
                return true;
            }
            else
            {
                this.Message = customorpaymentDAL.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(CustomorPaymentENT entCustomorPayment)
        {
            CustomorPaymentDAL customorpaymentDAL = new CustomorPaymentDAL();
            if (customorpaymentDAL.Update(entCustomorPayment))
            {
                return true;
            }
            else
            {
                this.Message = customorpaymentDAL.Message;
                return false;
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 CustomorPaymentID)
        {
            CustomorPaymentDAL customorpaymentDAL = new CustomorPaymentDAL();
            if (customorpaymentDAL.Delete(CustomorPaymentID))
            {
                return true;
            }
            else
            {
                this.Message = customorpaymentDAL.Message;
                return false;
            }
        }

        #endregion Delete Operation

        #region Select Operations

        public DataTable SelectAll()
        {
            CustomorPaymentDAL customorpaymentDAL = new CustomorPaymentDAL();
            return customorpaymentDAL.SelectAll();
        }

        public CustomorPaymentENT SelectByPK(SqlInt32 CustomorPaymentID)
        {
            CustomorPaymentDAL customorpaymentDAL = new CustomorPaymentDAL();
            return customorpaymentDAL.SelectByPK(CustomorPaymentID);
        }

       


        #endregion Select Operations
    }
}