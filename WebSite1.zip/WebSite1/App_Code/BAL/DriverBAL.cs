﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverBAL
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class DriverBAL : DriverBALBase
    {
        public DriverBAL()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}