﻿using MahiMilkDistribution.DAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverBALBase
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class DriverBALBase
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(DriverENT entDriver)
        {
            DriverDAL driverDAL = new DriverDAL();
            if (driverDAL.Insert(entDriver))
            {
                return true;
            }
            else
            {
                this.Message = driverDAL.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(DriverENT entDriver)
        {
            DriverDAL driverDAL = new DriverDAL();
            if (driverDAL.Update(entDriver))
            {
                return true;
            }
            else
            {
                this.Message = driverDAL.Message;
                return false;
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 DriverID)
        {
            DriverDAL driverDAL = new DriverDAL();
            if (driverDAL.Delete(DriverID))
            {
                return true;
            }
            else
            {
                this.Message = driverDAL.Message;
                return false;
            }
        }

        #endregion Delete Operation

        #region Select Operations

        public DataTable SelectAll()
        {
            DriverDAL driverDAL = new DriverDAL();
            return driverDAL.SelectAll();
        }

        public DriverENT SelectByPK(SqlInt32 DriverID)
        {
            DriverDAL driverDAL = new DriverDAL();
            return driverDAL.SelectByPK(DriverID);
        }

        public DataTable SelectDropDownList()
        {
            DriverDAL driverDAL = new DriverDAL();
            return driverDAL.SelectDropDownList();
        }


        #endregion Select Operations
    }
}