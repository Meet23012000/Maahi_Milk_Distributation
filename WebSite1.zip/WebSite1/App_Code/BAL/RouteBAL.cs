﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RouteBAL
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class RouteBAL : RouteBALBase
    {
        public RouteBAL()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}