﻿using MahiMilkDistribution.DAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RouteBALBase
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class RouteBALBase
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(RouteENT entRoute)
        {
            RouteDAL routeDAL = new RouteDAL();
            if (routeDAL.Insert(entRoute))
            {
                return true;
            }
            else
            {
                this.Message = routeDAL.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(RouteENT entRoute)
        {
            RouteDAL routeDAL = new RouteDAL();
            if (routeDAL.Update(entRoute))
            {
                return true;
            }
            else
            {
                this.Message = routeDAL.Message;
                return false;
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 RouteID)
        {
            RouteDAL routeDAL = new RouteDAL();
            if (routeDAL.Delete(RouteID))
            {
                return true;
            }
            else
            {
                this.Message = routeDAL.Message;
                return false;
            }
        }

        #endregion Delete Operation

        #region Select Operations

        public DataTable SelectAll()
        {
            RouteDAL routeDAL = new RouteDAL();
            return routeDAL.SelectAll();
        }

        public RouteENT SelectByPK(SqlInt32 RouteID)
        {
            RouteDAL routeDAL = new RouteDAL();
            return routeDAL.SelectByPK(RouteID);
        }

        public DataTable SelectDropDownList()
        {
            RouteDAL routeDAL = new RouteDAL();
            return routeDAL.SelectDropDownList();
        }



        #endregion Select Operations
    }
}