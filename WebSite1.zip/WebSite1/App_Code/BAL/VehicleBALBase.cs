﻿using MahiMilkDistribution.DAL;
using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for VehicleBALBase
/// </summary>
/// 
namespace MahiMilkDistribution.BAL
{
    public class VehicleBALBase
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(VehicleENT entVehicle)
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            if (vehicleDAL.Insert(entVehicle))
            {
                return true;
            }
            else
            {
                this.Message = vehicleDAL.Message;
                return false;
            }
        }

        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(VehicleENT entVehicle)
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            if (vehicleDAL.Update(entVehicle))
            {
                return true;
            }
            else
            {
                this.Message = vehicleDAL.Message;
                return false;
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 VehicleID)
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            if (vehicleDAL.Delete(VehicleID))
            {
                return true;
            }
            else
            {
                this.Message = vehicleDAL.Message;
                return false;
            }
        }

        #endregion Delete Operation

        #region Select Operations

        public DataTable SelectAll()
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            return vehicleDAL.SelectAll();
        }

        public VehicleENT SelectByPK(SqlInt32 VehicleID)
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            return vehicleDAL.SelectByPK(VehicleID);
        }

        public DataTable SelectDropDownList()
        {
            VehicleDAL vehicleDAL = new VehicleDAL();
            return vehicleDAL.SelectDropDownList();
        }



        #endregion Select Operations
    }
}