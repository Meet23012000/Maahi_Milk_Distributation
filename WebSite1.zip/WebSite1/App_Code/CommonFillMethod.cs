﻿using MahiMilkDistribution.BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for CommonFillMethod
/// </summary>
/// 
namespace MahiMilkDistribution
{
    public class CommonFillMethod
    {
        #region fillDropDownProductID
        public static void FillDropDownListProductID(DropDownList ddl)
        {
            ProductBAL balProduct = new ProductBAL();
            ddl.DataSource = balProduct.SelectDropDownList();
            ddl.DataTextField = "ProductName";
            ddl.DataValueField = "ProductID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Product", "-1"));
        }
        #endregion fillDropDownProductID

        #region fillDropDownVehicleID
        public static void FillDropDownListVehicleID(DropDownList ddl)
        {
            VehicleBAL balVehicle = new VehicleBAL();
            ddl.DataSource = balVehicle.SelectDropDownList();
            ddl.DataTextField = "VehicleNO";
            ddl.DataValueField = "VehicleID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Vehicle", "-1"));
        }
        #endregion fillDropDownVehicleID

        #region fillDropDownDriverID
        public static void FillDropDownListDriverID(DropDownList ddl)
        {
            DriverBAL balDriver = new DriverBAL();
            ddl.DataSource = balDriver.SelectDropDownList();
            ddl.DataTextField = "DriverName";
            ddl.DataValueField = "DriverID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Driver", "-1"));
        }
        #endregion fillDropDownVehicleID

        #region fillDropDownCustomorID
        public static void FillDropDownListCustomorID(DropDownList ddl)
        {
            CustomorBAL balCustomor = new CustomorBAL();
            ddl.DataSource = balCustomor.SelectDropDownList();
            ddl.DataTextField = "CustomorName";
            ddl.DataValueField = "CustomorID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Customor", "-1"));
        }
        #endregion fillDropDownCustomorID

        #region fillDropDownCustomorIDVilage
        public static void FillDropDownListVillageCustomorID(DropDownList ddl)
        {
            CustomorBAL balCustomor = new CustomorBAL();
            ddl.DataSource = balCustomor.SelectDropDownListVillage();
            ddl.DataTextField = "VillageName";
            ddl.DataValueField = "CustomorID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Village Name", "-1"));
        }
        #endregion fillDropDownCustomorIDVillage


        #region fillDropDownCustomorIDShop
        public static void FillDropDownListShopCustomorID(DropDownList ddl)
        {
            CustomorBAL balCustomor = new CustomorBAL();
            ddl.DataSource = balCustomor.SelectDropDownListShop();
            ddl.DataTextField = "ShopName";
            ddl.DataValueField = "CustomorID";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Shop Name", "-1"));
        }
        #endregion fillDropDownCustomorIDVillage
    }
}