﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorHeaderDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class CustomorHeaderDALBase : DatabaseConfig
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(CustomorHeaderENT entCustomorHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorHeader_Insert";
                        objCmd.Parameters.AddWithValue("@CustomorID", entCustomorHeader.CustomorID);
                        objCmd.Parameters.AddWithValue("@Date", entCustomorHeader.Date);
                        objCmd.Parameters.AddWithValue("@CustomorTotalQts", entCustomorHeader.CustomorTotalQts);
                        objCmd.Parameters.AddWithValue("@CustomorTotalRate", entCustomorHeader.CustomorTotalRate);

                        //objCmd.Parameters.AddWithValue("@UserID", entContact.UserID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(CustomorHeaderENT entCustomorHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorHeader_UpdateByPK";
                        objCmd.Parameters.AddWithValue("@CustomorHeaderID", entCustomorHeader.CustomorHeaderID);
                        objCmd.Parameters.AddWithValue("@CustomorID", entCustomorHeader.CustomorID);
                        objCmd.Parameters.AddWithValue("@Date", entCustomorHeader.Date);
                        objCmd.Parameters.AddWithValue("@CustomorTotalQts", entCustomorHeader.CustomorTotalQts);
                        objCmd.Parameters.AddWithValue("@CustomorTotalRate", entCustomorHeader.CustomorTotalRate);


                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 CustomorHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorHeader_DeletePK";
                        objCmd.Parameters.AddWithValue("@CustomorHeaderID", CustomorHeaderID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Delete Operation

        #region Select Operation

        public DataTable SelectAll()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorHeader_SelectAll";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        public CustomorHeaderENT SelectByPK(SqlInt32 CustomorHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorHeader_SelectPK";
                        objCmd.Parameters.AddWithValue("@CustomorHeaderID", CustomorHeaderID);
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        CustomorHeaderENT entCustomorHeader = new CustomorHeaderENT();

                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                //if (!objSDR["CountryID"].Equals(DBNull.Value))
                                //{
                                //    entCountry.CountryID = Convert.ToInt32(objSDR["CountryID"]);
                                //}
                              
                                if (!objSDR["CustomorID"].Equals(DBNull.Value))
                                {
                                    entCustomorHeader.CustomorID = Convert.ToInt32(objSDR["CustomorID"]);
                                }
                                if (!objSDR["Date"].Equals(DBNull.Value))
                                {
                                    entCustomorHeader.Date = Convert.ToDateTime(objSDR["Date"]);
                                }
                                if (!objSDR["CustomorTotalQts"].Equals(DBNull.Value))
                                {
                                    entCustomorHeader.CustomorTotalQts = Convert.ToString(objSDR["CustomorTotalQts"]);
                                }
                                if (!objSDR["CustomorTotalRate"].Equals(DBNull.Value))
                                {
                                    entCustomorHeader.CustomorTotalRate = Convert.ToString(objSDR["CustomorTotalRate"]);
                                }
                            }
                        }

                        return entCustomorHeader;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }


       



        #endregion Select Operation
    }
}