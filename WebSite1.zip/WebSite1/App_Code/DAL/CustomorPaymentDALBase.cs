﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorPaymentDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public abstract class CustomorPaymentDALBase : DatabaseConfig
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(CustomorPaymentENT entCustomorPayment)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorPayment_Insert";
                        objCmd.Parameters.AddWithValue("@CustomorID", entCustomorPayment.CustomorID);
                        objCmd.Parameters.AddWithValue("@TotalAmount", entCustomorPayment.TotalAmount);
                        objCmd.Parameters.AddWithValue("@PaidAmount", entCustomorPayment.PaidAmount);
                        objCmd.Parameters.AddWithValue("@PaymentDate", entCustomorPayment.PaymentDate);
                       

                        //objCmd.Parameters.AddWithValue("@UserID", entContact.UserID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(CustomorPaymentENT entCustomorPayment)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorPayment_UpdateByPK";
                        objCmd.Parameters.AddWithValue("@CustomorPaymentID", entCustomorPayment.CustomorPaymentID);
                        objCmd.Parameters.AddWithValue("@CustomorID", entCustomorPayment.CustomorID);
                        objCmd.Parameters.AddWithValue("@TotalAmount", entCustomorPayment.TotalAmount);
                        objCmd.Parameters.AddWithValue("@PaidAmount", entCustomorPayment.PaidAmount);
                        objCmd.Parameters.AddWithValue("@PaymentDate", entCustomorPayment.PaymentDate);
                       

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 CustomorPaymentID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorPayment_DeletePK";
                        objCmd.Parameters.AddWithValue("@CustomorPaymentID", CustomorPaymentID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Delete Operation

        #region Select Operation

        public DataTable SelectAll()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorPayment_SelectAll";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        public CustomorPaymentENT SelectByPK(SqlInt32 CustomorPaymentID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_CustomorPayment_SelectPK";
                        objCmd.Parameters.AddWithValue("@CustomorPaymentID", CustomorPaymentID);
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        CustomorPaymentENT entCustomorPayment = new CustomorPaymentENT();

                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                //if (!objSDR["CountryID"].Equals(DBNull.Value))
                                //{
                                //    entCountry.CountryID = Convert.ToInt32(objSDR["CountryID"]);
                                //}
                                if (!objSDR["CustomorID"].Equals(DBNull.Value))
                                {
                                    entCustomorPayment.CustomorID = Convert.ToInt32(objSDR["CustomorID"]);
                                }
                                if (!objSDR["TotalAmount"].Equals(DBNull.Value))
                                {
                                    entCustomorPayment.TotalAmount = Convert.ToString(objSDR["TotalAmount"]);
                                }
                                if (!objSDR["PaidAmount"].Equals(DBNull.Value))
                                {
                                    entCustomorPayment.PaidAmount = Convert.ToString(objSDR["PaidAmount"]);
                                }
                                if (!objSDR["PaymentDate"].Equals(DBNull.Value))
                                {
                                    entCustomorPayment.PaymentDate = Convert.ToDateTime(objSDR["PaymentDate"]);
                                }
                                
                            }
                        }

                        return entCustomorPayment;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }



        



        #endregion Select Operation
    }
}