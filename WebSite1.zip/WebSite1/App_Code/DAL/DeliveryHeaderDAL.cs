﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryHeaderDAL
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DeliveryHeaderDAL : DeliveryHeaderDALBase
    {
        
    }
}