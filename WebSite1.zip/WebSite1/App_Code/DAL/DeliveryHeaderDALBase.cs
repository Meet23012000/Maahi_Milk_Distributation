﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryHeaderDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DeliveryHeaderDALBase : DatabaseConfig
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(DeliveryHeaderENT entDeliveryHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DeliveryHeader_Insert";
                        objCmd.Parameters.AddWithValue("@DriverID", entDeliveryHeader.DriverID);
                        objCmd.Parameters.AddWithValue("@CustomorID", entDeliveryHeader.CustomorID);
                        objCmd.Parameters.AddWithValue("@Date", entDeliveryHeader.Date);
                        objCmd.Parameters.AddWithValue("@DeliveryTotalQts", entDeliveryHeader.DeliveryTotalQts);
                        objCmd.Parameters.AddWithValue("@DeliveryTotalRate", entDeliveryHeader.DeliveryTotalRate);
                        

                        //objCmd.Parameters.AddWithValue("@UserID", entContact.UserID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(DeliveryHeaderENT entDeliveryHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DeliveryHeader_UpdateByPK";
                        objCmd.Parameters.AddWithValue("@DeliveryHeaderID", entDeliveryHeader.DeliveryHeaderID);
                        objCmd.Parameters.AddWithValue("@DriverID", entDeliveryHeader.DriverID);
                        objCmd.Parameters.AddWithValue("@CustomorID", entDeliveryHeader.CustomorID);
                        objCmd.Parameters.AddWithValue("@Date", entDeliveryHeader.Date);
                        objCmd.Parameters.AddWithValue("@DeliveryTotalQts", entDeliveryHeader.DeliveryTotalQts);
                        objCmd.Parameters.AddWithValue("@DeliveryTotalRate", entDeliveryHeader.DeliveryTotalRate);
                        

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 DeliveryHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DeliveryHeader_DeletePK";
                        objCmd.Parameters.AddWithValue("@DeliveryHeaderID", DeliveryHeaderID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Delete Operation

        #region Select Operation

        public DataTable SelectAll()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DeliveryHeader_SelectAll";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        public DeliveryHeaderENT SelectByPK(SqlInt32 DeliveryHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DeliveryHeader_SelectPK";
                        objCmd.Parameters.AddWithValue("@DeliveryHeaderID", DeliveryHeaderID);
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DeliveryHeaderENT entDeliveryHeader = new DeliveryHeaderENT();

                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                //if (!objSDR["CountryID"].Equals(DBNull.Value))
                                //{
                                //    entCountry.CountryID = Convert.ToInt32(objSDR["CountryID"]);
                                //}

                                if (!objSDR["DriverID"].Equals(DBNull.Value))
                                {
                                    entDeliveryHeader.DriverID = Convert.ToInt32(objSDR["DriverID"]);
                                }
                                if (!objSDR["CustomorID"].Equals(DBNull.Value))
                                {
                                    entDeliveryHeader.CustomorID = Convert.ToInt32(objSDR["CustomorID"]);
                                }
                                if (!objSDR["Date"].Equals(DBNull.Value))
                                {
                                    entDeliveryHeader.Date = Convert.ToDateTime(objSDR["Date"]);
                                }
                                if (!objSDR["DeliveryTotalQts"].Equals(DBNull.Value))
                                {
                                    entDeliveryHeader.DeliveryTotalQts = Convert.ToString(objSDR["DeliveryTotalQts"]);
                                }
                                if (!objSDR["DeliveryTotalRate"].Equals(DBNull.Value))
                                {
                                    entDeliveryHeader.DeliveryTotalRate = Convert.ToString(objSDR["DeliveryTotalRate"]);
                                }
                               
                            }
                        }

                        return entDeliveryHeader;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }






        #endregion Select Operation
    }
}