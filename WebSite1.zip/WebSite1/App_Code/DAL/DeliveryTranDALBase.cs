﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryTranDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DeliveryTranDALBase : DatabaseConfig
    {
       
    }
}