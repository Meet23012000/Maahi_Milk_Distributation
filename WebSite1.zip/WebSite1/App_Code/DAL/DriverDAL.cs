﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverDAL
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DriverDAL : DriverDALBase
    {
        
    }
}