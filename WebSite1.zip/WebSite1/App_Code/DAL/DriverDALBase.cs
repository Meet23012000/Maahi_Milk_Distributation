﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public abstract class DriverDALBase : DatabaseConfig
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(DriverENT entDriver)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_Insert";
                        objCmd.Parameters.AddWithValue("@DriverName", entDriver.DriverName);
                        objCmd.Parameters.AddWithValue("@MobileNO", entDriver.MobileNO);
                        objCmd.Parameters.AddWithValue("@Address", entDriver.Address);
                        objCmd.Parameters.AddWithValue("@VehicleID", entDriver.VehicleID);
                        objCmd.Parameters.AddWithValue("@LicenseNO", entDriver.LicenseNO);
                        objCmd.Parameters.AddWithValue("@LicenseExpiredDate", entDriver.LicenseExpiredDate);
                        objCmd.Parameters.AddWithValue("@LicensePath", entDriver.LicensePath);

                        //objCmd.Parameters.AddWithValue("@UserID", entContact.UserID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(DriverENT entDriver)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_UpdateByPK";
                        objCmd.Parameters.AddWithValue("@DriverID", entDriver.DriverID);
                        objCmd.Parameters.AddWithValue("@DriverName", entDriver.DriverName);
                        objCmd.Parameters.AddWithValue("@MobileNO", entDriver.MobileNO);
                        objCmd.Parameters.AddWithValue("@Address", entDriver.Address);
                        objCmd.Parameters.AddWithValue("@VehicleID", entDriver.VehicleID);
                        objCmd.Parameters.AddWithValue("@LicenseNO", entDriver.LicenseNO);
                        objCmd.Parameters.AddWithValue("@LicenseExpiredDate", entDriver.LicenseExpiredDate);
                        objCmd.Parameters.AddWithValue("@LicensePath", entDriver.LicensePath);


                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 DriverID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_DeletePK";
                        objCmd.Parameters.AddWithValue("@DriverID", DriverID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Delete Operation

        #region Select Operation

        public DataTable SelectAll()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_SelectAll";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        public DriverENT SelectByPK(SqlInt32 DriverID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_SelectPK";
                        objCmd.Parameters.AddWithValue("@DriverID", DriverID);
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DriverENT entDriver = new DriverENT();

                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                //if (!objSDR["CountryID"].Equals(DBNull.Value))
                                //{
                                //    entCountry.CountryID = Convert.ToInt32(objSDR["CountryID"]);
                                //}
                                if (!objSDR["DriverName"].Equals(DBNull.Value))
                                {
                                    entDriver.DriverName = Convert.ToString(objSDR["DriverName"]);
                                }
                                if (!objSDR["MobileNO"].Equals(DBNull.Value))
                                {
                                    entDriver.MobileNO = Convert.ToString(objSDR["MobileNO"]);
                                }
                                if (!objSDR["Address"].Equals(DBNull.Value))
                                {
                                    entDriver.Address = Convert.ToString(objSDR["Address"]);
                                }
                                if (!objSDR["VehicleID"].Equals(DBNull.Value))
                                {
                                    entDriver.VehicleID = Convert.ToInt32(objSDR["VehicleID"]);
                                }
                                if (!objSDR["LicenseNO"].Equals(DBNull.Value))
                                {
                                    entDriver.LicenseNO = Convert.ToString(objSDR["LicenseNO"]);
                                }
                                if (!objSDR["LicenseExpiredDate"].Equals(DBNull.Value))
                                {
                                    entDriver.LicenseExpiredDate = Convert.ToDateTime(objSDR["LicenseExpiredDate"]);
                                }
                                if (!objSDR["LicensePath"].Equals(DBNull.Value))
                                {
                                    entDriver.LicensePath = Convert.ToString(objSDR["LicensePath"]);
                                }
                            }
                        }

                        return entDriver;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }


        public DataTable SelectDropDownList()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_Driver_SelectDropDownList";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }



        #endregion Select Operation
    }
}