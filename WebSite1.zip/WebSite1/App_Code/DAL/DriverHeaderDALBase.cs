﻿using MahiMilkDistribution.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverHeaderDALBase
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DriverHeaderDALBase : DatabaseConfig
    {
        #region Local Variables

        protected string _Message;
        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variables

        #region Insert Operation

        public Boolean Insert(DriverHeaderENT entDriverHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DriverHeader_Insert";
                        objCmd.Parameters.AddWithValue("@DriverID", entDriverHeader.DriverID);
                        objCmd.Parameters.AddWithValue("@Date", entDriverHeader.Date);
                        objCmd.Parameters.AddWithValue("@DriverTotalCrate", entDriverHeader.DriverTotalCrate);
                        objCmd.Parameters.AddWithValue("@DriverTotalQts", entDriverHeader.DriverTotalQts);
                        objCmd.Parameters.AddWithValue("@DriverTotalReturnQts", entDriverHeader.DriverTotalReturnQts);
                        objCmd.Parameters.AddWithValue("@DriverTotalRate", entDriverHeader.DriverTotalRate);

                        //objCmd.Parameters.AddWithValue("@UserID", entContact.UserID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }
        #endregion Insert Operation

        #region Update Operation

        public Boolean Update(DriverHeaderENT entDriverHeader)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DriverHeader_UpdateByPK";
                        objCmd.Parameters.AddWithValue("@DriverHeaderID", entDriverHeader.DriverHeaderID);
                        objCmd.Parameters.AddWithValue("@DriverID", entDriverHeader.DriverID);
                        objCmd.Parameters.AddWithValue("@Date", entDriverHeader.Date);
                        objCmd.Parameters.AddWithValue("@DriverTotalCrate", entDriverHeader.DriverTotalCrate);
                        objCmd.Parameters.AddWithValue("@DriverTotalQts", entDriverHeader.DriverTotalQts);
                        objCmd.Parameters.AddWithValue("@DriverTotalReturnQts", entDriverHeader.DriverTotalReturnQts);
                        objCmd.Parameters.AddWithValue("@DriverTotalRate", entDriverHeader.DriverTotalRate);


                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Update Operation

        #region Delete Operation

        public Boolean Delete(SqlInt32 DriverHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DriverHeader_DeletePK";
                        objCmd.Parameters.AddWithValue("@DriverHeaderID", DriverHeaderID);

                        #endregion Prepare Command

                        objCmd.ExecuteNonQuery();

                        return true;

                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        #endregion Delete Operation

        #region Select Operation

        public DataTable SelectAll()
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DriverHeader_SelectAll";
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }

        public DriverHeaderENT SelectByPK(SqlInt32 DriverHeaderID)
        {
            using (SqlConnection objConn = new SqlConnection(ConnectionString))
            {
                objConn.Open();
                using (SqlCommand objCmd = objConn.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objCmd.CommandType = CommandType.StoredProcedure;
                        objCmd.CommandText = "PR_DriverHeader_SelectPK";
                        objCmd.Parameters.AddWithValue("@DriverHeaderID", DriverHeaderID);
                        #endregion Prepare Command

                        #region ReadData and Set Controls
                        DriverHeaderENT entDribverHeader = new DriverHeaderENT();

                        using (SqlDataReader objSDR = objCmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                //if (!objSDR["CountryID"].Equals(DBNull.Value))
                                //{
                                //    entCountry.CountryID = Convert.ToInt32(objSDR["CountryID"]);
                                //}

                                if (!objSDR["DriverID"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.DriverID = Convert.ToInt32(objSDR["DriverID"]);
                                }
                                if (!objSDR["Date"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.Date = Convert.ToDateTime(objSDR["Date"]);
                                }
                                if (!objSDR["DriverTotalCrate"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.DriverTotalCrate = Convert.ToString(objSDR["DriverTotalCrate"]);
                                }
                                if (!objSDR["DriverTotalQts"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.DriverTotalQts = Convert.ToString(objSDR["DriverTotalQts"]);
                                }
                                if (!objSDR["DriverTotalReturnQts"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.DriverTotalReturnQts = Convert.ToString(objSDR["DriverTotalReturnQts"]);
                                }
                                if (!objSDR["DriverTotalRate"].Equals(DBNull.Value))
                                {
                                    entDribverHeader.DriverTotalRate = Convert.ToString(objSDR["DriverTotalRate"]);
                                }
                            }
                        }

                        return entDribverHeader;

                        #endregion ReadData and Set Controls
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConn.State == ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }
        }






        #endregion Select Operation
    }
}