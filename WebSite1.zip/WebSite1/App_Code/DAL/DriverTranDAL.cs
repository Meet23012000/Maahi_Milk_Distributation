﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverTranDAL
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class DriverTranDAL : DriverTranDALBase
    {
        public DriverTranDAL()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}