﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ProductDAL
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class ProductDAL :ProductDALBase
    {
       
    }
}