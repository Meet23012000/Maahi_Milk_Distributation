﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for VehicleDAL
/// </summary>
/// 
namespace MahiMilkDistribution.DAL
{
    public class VehicleDAL:VehicleDALBase
    {
        public VehicleDAL()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}