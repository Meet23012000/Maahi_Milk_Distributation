﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CompanyOrderHeaderENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CompanyOrderHeaderENTBase
    {
        protected SqlInt32 _CompanyOraderHeaderID;
        public SqlInt32 CompanyOraderHeaderID
        {
            get
            {
                return _CompanyOraderHeaderID;
            }
            set
            {
                _CompanyOraderHeaderID = value;
            }
        }
        protected SqlDateTime _Date;
        public SqlDateTime Date
        {
            get
            {
                return _Date;
            }
            set
            {
                _Date = value;
            }
        }

        protected SqlString _TotalCrate;
        public SqlString TotalCrate
        {
            get
            {
                return _TotalCrate;
            }
            set
            {
                _TotalCrate = value;
            }
        }

        protected SqlString _TotalRate;
        public SqlString TotalRate
        {
            get
            {
                return _TotalRate;
            }
            set
            {
                _TotalRate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}