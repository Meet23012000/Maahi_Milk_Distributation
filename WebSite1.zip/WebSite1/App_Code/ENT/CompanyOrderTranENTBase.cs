﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CompanyOrderTranENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CompanyOrderTranENTBase
    {
        protected SqlInt32 _CompanyOrdderTranID;
        public SqlInt32 CompanyOrdderTranID
        {
            get
            {
                return _CompanyOrdderTranID;
            }
            set
            {
                _CompanyOrdderTranID = value;
            }
        }

        protected SqlInt32 _CompanyOrderHeaderID;
        public SqlInt32 CompanyOrderHeaderID
        {
            get
            {
                return _CompanyOrderHeaderID;
            }
            set
            {
                _CompanyOrderHeaderID = value;
            }
        }
        protected SqlInt32 _ProductID;
        public SqlInt32 ProductID
        {
            get
            {
                return _ProductID;
            }
            set
            {
                _ProductID = value;
            }
        }

        protected SqlString _NoOfCrate;
        public SqlString NoOfCrate
        {
            get
            {
                return _NoOfCrate;
            }
            set
            {
                _NoOfCrate = value;
            }
        }

        protected SqlString _Total;
        public SqlString Total
        {
            get
            {
                return _Total;
            }
            set
            {
                _Total = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}