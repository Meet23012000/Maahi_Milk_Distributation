﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CustomorENTBase
    {
        protected SqlInt32 _CustomorID;
        public SqlInt32 CustomorID
        {
            get
            {
                return _CustomorID;
            }
            set
            {
                _CustomorID = value;
            }
        }

        protected SqlString _CustomorName;
        public SqlString CustomorName
        {
            get
            {
                return _CustomorName;
            }
            set
            {
                _CustomorName = value;
            }
        }
        protected SqlString _MobileNO;
        public SqlString MobileNO
        {
            get
            {
                return _MobileNO;
            }
            set
            {
                _MobileNO = value;
            }
        }

        protected SqlString _EmailID;
        public SqlString EmailID
        {
            get
            {
                return _EmailID;
            }
            set
            {
                _EmailID = value;
            }
        }

        protected SqlString _Address;
        public SqlString Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }

        protected SqlInt32 _DriverID;
        public SqlInt32 DriverID
        {
            get
            {
                return _DriverID;
            }
            set
            {
                _DriverID = value;
            }
        }

        protected SqlString _VillageName;
        public SqlString VillageName
        {
            get
            {
                return _VillageName;
            }
            set
            {
                _VillageName = value;
            }
        }

        protected SqlString _ShopName;
        public SqlString ShopName
        {
            get
            {
                return _ShopName;
            }
            set
            {
                _ShopName = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }

    }
}