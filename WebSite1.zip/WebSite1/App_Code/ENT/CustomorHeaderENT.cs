﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorHeaderENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class CustomorHeaderENT :CustomorHeaderENTBase
    {
        public CustomorHeaderENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}