﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorHeaderENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CustomorHeaderENTBase
    {
        protected SqlInt32 _CustomorHeaderID;
        public SqlInt32 CustomorHeaderID
        {
            get
            {
                return _CustomorHeaderID;
            }
            set
            {
                _CustomorHeaderID = value;
            }
        }

        protected SqlInt32 _CustomorID;
        public SqlInt32 CustomorID
        {
            get
            {
                return _CustomorID;
            }
            set
            {
                _CustomorID = value;
            }
        }

        protected SqlDateTime _Date;
        public SqlDateTime Date
        {
            get
            {
                return _Date;
            }
            set
            {
                _Date = value;
            }
        }

        protected SqlString _CustomorTotalQts;
        public SqlString CustomorTotalQts
        {
            get
            {
                return _CustomorTotalQts;
            }
            set
            {
                _CustomorTotalQts = value;
            }
        }

        protected SqlString _CustomorTotalRate;
        public SqlString CustomorTotalRate
        {
            get
            {
                return _CustomorTotalRate;
            }
            set
            {
                _CustomorTotalRate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}