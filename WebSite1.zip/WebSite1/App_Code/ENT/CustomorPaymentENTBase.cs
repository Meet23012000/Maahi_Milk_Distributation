﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorPaymentENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CustomorPaymentENTBase
    {
        protected SqlInt32 _CustomorPaymentID;
        public SqlInt32 CustomorPaymentID
        {
            get
            {
                return _CustomorPaymentID;
            }
            set
            {
                _CustomorPaymentID = value;
            }
        }

        protected SqlInt32 _CustomorID;
        public SqlInt32 CustomorID
        {
            get
            {
                return _CustomorID;
            }
            set
            {
                _CustomorID = value;
            }
        }

        protected SqlString _TotalAmount;
        public SqlString TotalAmount
        {
            get
            {
                return _TotalAmount;
            }
            set
            {
                _TotalAmount = value;
            }
        }

        protected SqlString _PaidAmount;
        public SqlString PaidAmount
        {
            get
            {
                return _PaidAmount;
            }
            set
            {
                _PaidAmount = value;
            }
        }

        protected SqlDateTime _PaymentDate;
        public SqlDateTime PaymentDate
        {
            get
            {
                return _PaymentDate;
            }
            set
            {
                _PaymentDate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}