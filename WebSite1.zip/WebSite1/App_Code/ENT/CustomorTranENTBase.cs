﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomorTranENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class CustomorTranENTBase
    {
        protected SqlInt32 _CustomorTranID;
        public SqlInt32 CustomorTranID
        {
            get
            {
                return _CustomorTranID;
            }
            set
            {
                _CustomorTranID = value;
            }
        }

        protected SqlInt32 _CustomorHeaderID;
        public SqlInt32 CustomorHeaderID
        {
            get
            {
                return _CustomorHeaderID;
            }
            set
            {
                _CustomorHeaderID = value;
            }
        }

        protected SqlInt32 _ProductID;
        public SqlInt32 ProductID
        {
            get
            {
                return _ProductID;
            }
            set
            {
                _ProductID = value;
            }
        }

        protected SqlString _Qts;
        public SqlString Qts
        {
            get
            {
                return _Qts;
            }
            set
            {
                _Qts = value;
            }
        }

        protected SqlString _Total;
        public SqlString Total
        {
            get
            {
                return _Total;
            }
            set
            {
                _Total = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}