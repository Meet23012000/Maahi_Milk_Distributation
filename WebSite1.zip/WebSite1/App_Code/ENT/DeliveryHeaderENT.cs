﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryHeaderENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class DeliveryHeaderENT :DeliveryHeaderENTBase
    {
        public DeliveryHeaderENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}