﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryHeaderENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class DeliveryHeaderENTBase
    {
        protected SqlInt32 _DeliveryHeaderID;
        public SqlInt32 DeliveryHeaderID
        {
            get
            {
                return _DeliveryHeaderID;
            }
            set
            {
                _DeliveryHeaderID = value;
            }
        }

        protected SqlInt32 _DriverID;
        public SqlInt32 DriverID
        {
            get
            {
                return _DriverID;
            }
            set
            {
                _DriverID = value;
            }
        }

        protected SqlInt32 _CustomorID;
        public SqlInt32 CustomorID
        {
            get
            {
                return _CustomorID;
            }
            set
            {
                _CustomorID = value;
            }
        }

        protected SqlDateTime _Date;
        public SqlDateTime Date
        {
            get
            {
                return _Date;
            }
            set
            {
                _Date = value;
            }
        }

        protected SqlString _DeliveryTotalQts;
        public SqlString DeliveryTotalQts
        {
            get
            {
                return _DeliveryTotalQts;
            }
            set
            {
                _DeliveryTotalQts = value;
            }
        }

        protected SqlString _DeliveryTotalRate;
        public SqlString DeliveryTotalRate
        {
            get
            {
                return _DeliveryTotalRate;
            }
            set
            {
                _DeliveryTotalRate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }

    }
}