﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryTranENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class DeliveryTranENT:DeliveryTranENTBase
    {
        public DeliveryTranENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}