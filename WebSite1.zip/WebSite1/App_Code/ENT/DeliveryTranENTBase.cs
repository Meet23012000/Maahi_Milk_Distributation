﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryTranENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class DeliveryTranENTBase
    {
        protected SqlInt32 _DeliveryTranID;
        public SqlInt32 DeliveryTranID
        {
            get
            {
                return _DeliveryTranID;
            }
            set
            {
                _DeliveryTranID = value;
            }
        }

        protected SqlInt32 _DeliveryHederID;
        public SqlInt32 DeliveryHederID
        {
            get
            {
                return _DeliveryHederID;
            }
            set
            {
                _DeliveryHederID = value;
            }
        }
        protected SqlInt32 _ProductID;
        public SqlInt32 ProductID
        {
            get
            {
                return _ProductID;
            }
            set
            {
                _ProductID = value;
            }
        }

        protected SqlString _Qts;
        public SqlString Qts
        {
            get
            {
                return _Qts;
            }
            set
            {
                _Qts = value;
            }
        }

        protected SqlString _Total;
        public SqlString Total
        {
            get
            {
                return _Total;
            }
            set
            {
                _Total = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}