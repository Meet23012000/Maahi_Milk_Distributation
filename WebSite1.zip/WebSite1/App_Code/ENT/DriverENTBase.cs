﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class DriverENTBase
    {
        protected SqlInt32 _DriverID;
        public SqlInt32 DriverID
        {
            get
            {
                return _DriverID;
            }
            set
            {
                _DriverID = value;
            }
        }

        protected SqlString _DriverName;
        public SqlString DriverName
        {
            get
            {
                return _DriverName;
            }
            set
            {
                _DriverName = value;
            }
        }

        protected SqlString _MobileNO;
        public SqlString MobileNO
        {
            get
            {
                return _MobileNO;
            }
            set
            {
                _MobileNO = value;
            }
        }

        protected SqlString _Address;
        public SqlString Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }

        protected SqlInt32 _VehicleID;
        public SqlInt32 VehicleID
        {
            get
            {
                return _VehicleID;
            }
            set
            {
                _VehicleID = value;
            }
        }

        protected SqlString _LicenseNO;
        public SqlString LicenseNO
        {
            get
            {
                return _LicenseNO;
            }
            set
            {
                _LicenseNO = value;
            }
        }

        protected SqlDateTime _LicenseExpiredDate;
        public SqlDateTime LicenseExpiredDate
        {
            get
            {
                return _LicenseExpiredDate;
            }
            set
            {
                _LicenseExpiredDate = value;
            }
        }

        protected SqlString _LicensePath;
        public SqlString LicensePath
        {
            get
            {
                return _LicensePath;
            }
            set
            {
                _LicensePath = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}