﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverHeaderENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class DriverHeaderENT :DriverHeaderENTBase
    {
        public DriverHeaderENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}