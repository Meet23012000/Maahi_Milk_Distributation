﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverHeaderENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class DriverHeaderENTBase
    {
        protected SqlInt32 _DriverHeaderID;
        public SqlInt32 DriverHeaderID
        {
            get
            {
                return _DriverHeaderID;
            }
            set
            {
                _DriverHeaderID = value;
            }
        }

        protected SqlInt32 _DriverID;
        public SqlInt32 DriverID
        {
            get
            {
                return _DriverID;
            }
            set
            {
                _DriverID = value;
            }
        }

        protected SqlDateTime _Date;
        public SqlDateTime Date
        {
            get
            {
                return _Date;
            }
            set
            {
                _Date = value;
            }
        }

        protected SqlString _DriverTotalCrate;
        public SqlString DriverTotalCrate
        {
            get
            {
                return _DriverTotalCrate;
            }
            set
            {
                _DriverTotalCrate = value;
            }
        }

        protected SqlString _DriverTotalQts;
        public SqlString DriverTotalQts
        {
            get
            {
                return _DriverTotalQts;
            }
            set
            {
                _DriverTotalQts = value;
            }
        }

        protected SqlString _DriverTotalReturnQts;
        public SqlString DriverTotalReturnQts
        {
            get
            {
                return _DriverTotalReturnQts;
            }
            set
            {
                _DriverTotalReturnQts = value;
            }
        }

        protected SqlString _DriverTotalRate;
        public SqlString DriverTotalRate
        {
            get
            {
                return _DriverTotalRate;
            }
            set
            {
                _DriverTotalRate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}