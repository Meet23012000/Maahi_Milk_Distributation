﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverTranENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class DriverTranENT:DriverTranENTBase
    {
        public DriverTranENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}