﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DriverTranENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class DriverTranENTBase
    {
        protected SqlInt32 _DriverTranID;
        public SqlInt32 DriverTranID
        {
            get
            {
                return _DriverTranID;
            }
            set
            {
                _DriverTranID = value;
            }
        }

        protected SqlInt32 _DriverHeaderID;
        public SqlInt32 DriverHeaderID
        {
            get
            {
                return _DriverHeaderID;
            }
            set
            {
                _DriverHeaderID = value;
            }
        }

        protected SqlInt32 _productID;
        public SqlInt32 productID
        {
            get
            {
                return _productID;
            }
            set
            {
                _productID = value;
            }
        }

        protected SqlString _NoOfCrate;
        public SqlString NoOfCrate
        {
            get
            {
                return _NoOfCrate;
            }
            set
            {
                _NoOfCrate = value;
            }
        }
        protected SqlString _Qts;
        public SqlString Qts
        {
            get
            {
                return _Qts;
            }
            set
            {
                _Qts = value;
            }
        }

        protected SqlString _ReturnQts;
        public SqlString ReturnQts
        {
            get
            {
                return _ReturnQts;
            }
            set
            {
                _ReturnQts = value;
            }
        }

        protected SqlString _Total;
        public SqlString Total
        {
            get
            {
                return _Total;
            }
            set
            {
                _Total = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }

    }
}