﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ProductENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class ProductENTBase
    {
        protected SqlInt32 _ProductID;
        public SqlInt32 ProductID
        {
            get
            {
                return _ProductID;
            }
            set
            {
                _ProductID = value;
            }
        }

        protected SqlString _ProductName;
        public SqlString ProductName
        {
            get
            {
                return _ProductName;
            }
            set
            {
                _ProductName = value;
            }
        }

        protected SqlString _ProductRate;
        public SqlString ProductRate
        {
            get
            {
                return _ProductRate;
            }
            set
            {
                _ProductRate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}