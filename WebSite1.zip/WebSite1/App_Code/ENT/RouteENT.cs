﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RouteENT
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public class RouteENT : RouteENTBase
    {
        
    }
}