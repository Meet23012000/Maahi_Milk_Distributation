﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RouteENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class RouteENTBase
    {
        protected SqlInt32 _RouteID;
        public SqlInt32 RouteID
        {
            get
            {
                return _RouteID;
            }
            set
            {
                _RouteID = value;
            }
        }

        protected SqlString _RouteNO;
        public SqlString RouteNO
        {
            get
            {
                return _RouteNO;
            }
            set
            {
                _RouteNO = value;
            }
        }

        protected SqlString _RouteName;
        public SqlString RouteName
        {
            get
            {
                return _RouteName;
            }
            set
            {
                _RouteName = value;
            }
        }

        protected SqlInt32 _DriverID;
        public SqlInt32 DriverID
        {
            get
            {
                return _DriverID;
            }
            set
            {
                _DriverID = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}