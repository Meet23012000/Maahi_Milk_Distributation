﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for VehicleENTBase
/// </summary>
/// 
namespace MahiMilkDistribution.ENT
{
    public abstract class VehicleENTBase
    {
        protected SqlInt32 _VehicleID;
        public SqlInt32 VehicleID
        {
            get
            {
                return _VehicleID;
            }
            set
            {
                _VehicleID = value;
            }
        }

        protected SqlString _VehicleType;
        public SqlString VehicleType
        {
            get
            {
                return _VehicleType;
            }
            set
            {
                _VehicleType = value;
            }
        }

        protected SqlString _VehicleNO;
        public SqlString VehicleNO
        {
            get
            {
                return _VehicleNO;
            }
            set
            {
                _VehicleNO = value;
            }
        }

        protected SqlString _OwnerName;
        public SqlString OwnerName
        {
            get
            {
                return _OwnerName;
            }
            set
            {
                _OwnerName = value;
            }
        }

        protected SqlString _MobileNO;
        public SqlString MobileNO
        {
            get
            {
                return _MobileNO;
            }
            set
            {
                _MobileNO = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}