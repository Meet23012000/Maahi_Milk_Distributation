// Call the dataTables jQuery plugin
$(document).ready(function() {
    $('#sample_1').DataTable();
});
